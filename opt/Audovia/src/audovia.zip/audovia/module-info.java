module audovia
{
	requires java.desktop;
	requires java.sql;
	requires java.prefs;
	requires org.apache.derby.engine;
	requires org.apache.derby.commons;
	requires org.apache.derby.tools;

}